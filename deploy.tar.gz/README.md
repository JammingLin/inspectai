# InspectAI Landing Page

AI-powered home inspection report generator — Waitlist landing page.

## Quick Deploy

### Option 1: Vercel CLI (Recommended)

```bash
cd inspectai-landing
npm i -g vercel
vercel login
vercel --prod
```

### Option 2: Vercel Dashboard

1. Go to [vercel.com/new](https://vercel.com/new)
2. Import this folder as a new project
3. Set environment variables:
   - `MAILCHIMP_API_KEY` — Your Mailchimp API key
   - `MAILCHIMP_AUDIENCE_ID` — Mailchimp audience ID for waitlist
4. Deploy

## Environment Variables

| Variable | Description |
|----------|-------------|
| `MAILCHIMP_API_KEY` | Mailchimp API key (format: `xxxxxxxxxxxx-us20`) |
| `MAILCHIMP_AUDIENCE_ID` | Audience ID for waitlist subscribers |

## Mailchimp Setup

1. Create new audience in Mailchimp for InspectAI waitlist
2. Get Audience ID from Audience → Settings → Audience name and defaults
3. Get API key from Account → Extras → API keys

## Domain

Recommended: `inspectai.cc` (check availability)

## Next Steps

- [ ] Deploy to Vercel
- [ ] Configure domain (inspectai.cc)
- [ ] Set up Mailchimp audience
- [ ] Add environment variables in Vercel
- [ ] Test subscription form
- [ ] Start promotion (Reddit, LinkedIn, ProductHunt)
